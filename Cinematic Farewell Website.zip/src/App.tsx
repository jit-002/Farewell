import { useEffect, useState } from 'react';
import Lenis from 'lenis@1.1.18';
import { Loader } from './components/Loader';
import { ScrollProgress } from './components/ScrollProgress';
import { HeroSection } from './components/HeroSection';
import { CountdownTimer } from './components/CountdownTimer';
import { StorySection } from './components/StorySection';
import { PhotoGallery } from './components/PhotoGallery';
import { VideoGallery } from './components/VideoGallery';
import { MemoryLane } from './components/MemoryLane';
import { WishesSection } from './components/WishesSection';
import { MemoryWall } from './components/MemoryWall';
import { MusicPlayer } from './components/MusicPlayer';
import { Footer } from './components/Footer';
import { CursorGlow } from './components/CursorGlow';
import { ScrollToTop } from './components/ScrollToTop';
import { Toaster } from './components/ui/sonner';

function App() {
  const [loading, setLoading] = useState(true);

  // Initialize Lenis smooth scrolling with buttery smooth settings
  useEffect(() => {
    if (!loading) {
      // Add lenis class to html element
      document.documentElement.classList.add('lenis', 'lenis-smooth');
      
      const lenis = new Lenis({
        duration: 1.5, // Increased for more smoothness
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)), // Custom easing for smoothness
        orientation: 'vertical',
        gestureOrientation: 'vertical',
        smoothWheel: true,
        smoothTouch: false, // Disable on touch for better mobile performance
        wheelMultiplier: 1, // Control wheel scroll speed
        touchMultiplier: 2,
        infinite: false,
      });

      // Optimize RAF loop for 60fps smoothness
      function raf(time: number) {
        lenis.raf(time);
        requestAnimationFrame(raf);
      }

      requestAnimationFrame(raf);

      // Expose lenis to window for debugging (optional)
      (window as any).lenis = lenis;

      return () => {
        lenis.destroy();
        document.documentElement.classList.remove('lenis', 'lenis-smooth');
      };
    }
  }, [loading]);

  // Disable default scroll restoration for smoother page loads
  useEffect(() => {
    if ('scrollRestoration' in history) {
      history.scrollRestoration = 'manual';
    }
  }, []);

  const storyData = [
    {
      title: 'The Journey',
      description: 'From strangers to family, from uncertainty to confidence. Every step of this journey has shaped who we are today.',
      backgroundImage: 'https://images.unsplash.com/photo-1761532276195-5d975abae829?w=1920',
    },
    {
      title: 'From Classrooms to Memories',
      description: 'Lessons learned went beyond textbooks. Friendship, laughter, tears, and growth - the real education happened in between.',
      backgroundImage: 'https://images.unsplash.com/photo-1741595304028-08fb698049e8?w=1920',
    },
    {
      title: 'One Last Day Together',
      description: 'As we stand on the threshold of tomorrow, we hold onto today. One last moment, one last laugh, one last memory together.',
      backgroundImage: 'https://images.unsplash.com/photo-1611571741792-edb58d0ceb67?w=1920',
    },
  ];

  return (
    <>
      {loading && <Loader onComplete={() => setLoading(false)} />}
      
      {!loading && (
        <div className="relative" style={{ willChange: 'transform' }}>
          {/* Global background gradient */}
          <div className="fixed inset-0 bg-gradient-to-br from-black via-[#4a0e0e] to-black -z-10" />
          
          {/* Scroll progress bar */}
          <ScrollProgress />
          
          {/* Cursor glow effect */}
          <CursorGlow />
          
          {/* Music player */}
          <MusicPlayer />
          
          {/* Scroll to top button */}
          <ScrollToTop />
          
          {/* Toast notifications */}
          <Toaster position="top-right" />

          {/* Main content */}
          <main className="relative">
            {/* Hero Section */}
            <HeroSection 
              backgroundImage="https://images.unsplash.com/photo-1591218214141-45545921d2d9?w=1920"
            />

            {/* Countdown Timer */}
            <CountdownTimer />

            {/* Story Sections with Doom Scrolling */}
            <div className="snap-y snap-mandatory">
              {storyData.map((story, index) => (
                <StorySection
                  key={index}
                  title={story.title}
                  description={story.description}
                  backgroundImage={story.backgroundImage}
                  index={index}
                />
              ))}
            </div>

            {/* Photo Gallery */}
            <PhotoGallery />

            {/* Video Gallery */}
            <VideoGallery />

            {/* Memory Lane Timeline */}
            <MemoryLane />

            {/* Wishes Section */}
            <WishesSection />

            {/* Interactive Memory Wall */}
            <MemoryWall />

            {/* Footer */}
            <Footer />
          </main>
        </div>
      )}
    </>
  );
}

export default App;