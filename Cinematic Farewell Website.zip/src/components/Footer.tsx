import { motion } from 'motion/react';
import { Heart, Sparkles } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative py-20 px-4 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-[#4a0e0e]/40 to-black" />

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#d4af37] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Main message */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <Sparkles className="w-16 h-16 text-[#d4af37] mx-auto mb-8 animate-pulse" />
          
          <h2
            className="text-5xl md:text-7xl font-bold mb-8"
            style={{
              background: 'linear-gradient(to right, #ffd700, #d4af37, #ffd700)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              animation: 'glow 3s ease-in-out infinite',
            }}
          >
            Thank You for the Memories
          </h2>

          <motion.p
            className="text-2xl md:text-3xl text-white/80 mb-8 leading-relaxed"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Though paths may diverge and distances may grow,
            <br />
            the memories we've made will forever glow.
          </motion.p>

          <motion.div
            className="glass-dark rounded-2xl p-8 inline-block mb-12"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <p className="text-xl text-white/70 mb-4 italic">
              "Don't cry because it's over,
              <br />
              smile because it happened."
            </p>
            <p className="text-[#d4af37]">— Dr. Seuss</p>
          </motion.div>
        </motion.div>

        {/* Divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.6 }}
          className="h-px bg-gradient-to-r from-transparent via-[#d4af37] to-transparent mb-12"
        />

        {/* Credits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="space-y-4"
        >
          <p className="text-white/60 text-lg flex items-center justify-center gap-2">
            Created with{' '}
            <Heart className="w-5 h-5 text-pink-500 fill-pink-500 inline animate-pulse" />{' '}
            by Class 11 Juniors
          </p>

          <p className="text-[#d4af37] font-bold text-lg">
            Designed and Developed by Jit
          </p>

          <p className="text-white/40 text-sm mt-8">
            Farewell 2026 • A Cinematic Experience
          </p>
        </motion.div>

        {/* Final glow effect */}
        <motion.div
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
          }}
        />
      </div>
    </footer>
  );
}
