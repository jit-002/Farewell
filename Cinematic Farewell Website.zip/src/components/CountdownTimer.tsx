import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, Sparkles } from 'lucide-react';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  const [prevTimeLeft, setPrevTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  const targetDate = new Date('2026-02-07T10:00:00').getTime();

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        const newTimeLeft = {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        };

        setPrevTimeLeft(timeLeft);
        setTimeLeft(newTimeLeft);
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetDate, timeLeft]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden py-20">
      {/* Animated background particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#d4af37] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="inline-block mb-6"
          >
            <Sparkles className="w-12 h-12 text-[#d4af37]" />
          </motion.div>
          
          <h2 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-[#ffd700] via-[#d4af37] to-[#ffd700] bg-clip-text text-transparent">
            The Moment Awaits
          </h2>
          
          <div className="flex items-center justify-center gap-3 text-gray-300 text-lg">
            <Calendar className="w-5 h-5 text-[#d4af37]" />
            <span>February 7, 2026</span>
            <span className="text-[#d4af37]">•</span>
            <Clock className="w-5 h-5 text-[#d4af37]" />
            <span>10:00 AM - 2:00 PM</span>
          </div>
        </motion.div>

        {/* Countdown Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 max-w-5xl mx-auto">
          {[
            { label: 'Days', value: timeLeft.days, prev: prevTimeLeft.days },
            { label: 'Hours', value: timeLeft.hours, prev: prevTimeLeft.hours },
            { label: 'Minutes', value: timeLeft.minutes, prev: prevTimeLeft.minutes },
            { label: 'Seconds', value: timeLeft.seconds, prev: prevTimeLeft.seconds },
          ].map((item, index) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="relative group"
            >
              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/20 to-[#4a0e0e]/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-500" />
              
              {/* Card */}
              <div className="relative glass-dark rounded-2xl p-6 md:p-8 border-2 border-[#d4af37]/30 overflow-hidden">
                {/* Shimmer effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-[#d4af37]/10 to-transparent"
                  animate={{ x: [-200, 200] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                />
                
                {/* Number with flip animation */}
                <div className="relative h-20 md:h-28 flex items-center justify-center overflow-hidden mb-3">
                  <AnimatePresence mode="popLayout">
                    <motion.div
                      key={item.value}
                      initial={{ y: item.value !== item.prev ? 50 : 0, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      exit={{ y: -50, opacity: 0 }}
                      transition={{ duration: 0.3, type: "spring", stiffness: 200 }}
                      className="text-6xl md:text-8xl font-bold bg-gradient-to-br from-[#ffd700] via-[#d4af37] to-[#ffd700] bg-clip-text text-transparent"
                      style={{
                        textShadow: '0 0 40px rgba(212, 175, 55, 0.5)',
                      }}
                    >
                      {String(item.value).padStart(2, '0')}
                    </motion.div>
                  </AnimatePresence>
                </div>
                
                {/* Label */}
                <motion.div
                  className="text-sm md:text-lg uppercase tracking-widest text-[#d4af37]"
                  animate={{ opacity: [0.7, 1, 0.7] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  {item.label}
                </motion.div>
                
                {/* Corner decorations */}
                <div className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-[#d4af37]/50" />
                <div className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-[#d4af37]/50" />
                <div className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-[#d4af37]/50" />
                <div className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-[#d4af37]/50" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center mt-12 text-xl md:text-2xl text-gray-300"
        >
          Until the memories become{' '}
          <span className="text-[#d4af37] font-semibold">eternal</span>
        </motion.p>
      </div>
    </section>
  );
}
