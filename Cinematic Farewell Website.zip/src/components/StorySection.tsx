import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';

interface StorySectionProps {
  title: string;
  description: string;
  backgroundImage: string;
  index: number;
}

export function StorySection({ title, description, backgroundImage, index }: StorySectionProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  // Enhanced parallax with smoother easing
  const y = useTransform(scrollYProgress, [0, 1], [150, -150]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0.9, 1, 1, 0.9]);
  const blur = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [10, 0, 0, 10]);

  return (
    <section ref={ref} className="h-screen flex items-center justify-center relative overflow-hidden snap-start">
      {/* Parallax background */}
      <motion.div
        style={{ y }}
        className="absolute inset-0"
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${backgroundImage})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/80" />
      </motion.div>

      {/* Content */}
      <motion.div
        style={{ opacity, scale }}
        className="relative z-10 max-w-4xl mx-auto px-4 text-center"
      >
        <motion.div
          initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8 }}
          className="glass-dark rounded-3xl p-8 md:p-12"
        >
          {/* Decorative corner elements */}
          <div className="absolute top-0 left-0 w-20 h-20 border-l-4 border-t-4 border-[#d4af37] rounded-tl-3xl" />
          <div className="absolute top-0 right-0 w-20 h-20 border-r-4 border-t-4 border-[#d4af37] rounded-tr-3xl" />
          <div className="absolute bottom-0 left-0 w-20 h-20 border-l-4 border-b-4 border-[#d4af37] rounded-bl-3xl" />
          <div className="absolute bottom-0 right-0 w-20 h-20 border-r-4 border-b-4 border-[#d4af37] rounded-br-3xl" />

          <motion.h2
            className="text-4xl md:text-6xl font-bold mb-6"
            style={{
              background: 'linear-gradient(to right, #ffd700, #d4af37, #ffd700)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            {title}
          </motion.h2>

          <motion.p
            className="text-xl md:text-2xl text-white/80 leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {description}
          </motion.p>

          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/10 to-transparent rounded-3xl blur-2xl pointer-events-none" />
        </motion.div>
      </motion.div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-[#d4af37]/50 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -50, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>
    </section>
  );
}