import { motion } from 'motion/react';
import { Calendar, Heart } from 'lucide-react';

interface Memory {
  year: string;
  title: string;
  description: string;
  image: string;
}

export function MemoryLane() {
  const memories: Memory[] = [
    {
      year: '2023',
      title: 'The Beginning',
      description: 'When we first walked through these gates, nervous yet excited for the journey ahead.',
      image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800',
    },
    {
      year: '2024',
      title: 'Growing Together',
      description: 'Late night study sessions, cafeteria gossip, and friendships that grew stronger.',
      image: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800',
    },
    {
      year: '2025',
      title: 'The Final Year',
      description: 'Board exams, college applications, and the realization that our time is running out.',
      image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800',
    },
    {
      year: '2026',
      title: 'The Farewell',
      description: 'One last gathering, one last laugh, one last memory to cherish forever.',
      image: 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=800',
    },
  ];

  return (
    <section className="min-h-screen py-20 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#4a0e0e]/30 to-black" />

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2
            className="text-5xl md:text-7xl font-bold mb-4"
            style={{
              background: 'linear-gradient(to right, #ffd700, #d4af37, #ffd700)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Memory Lane
          </h2>
          <p className="text-xl text-white/70">
            Walking down the path we've traveled together
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Center line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-[#d4af37] via-[#ffd700] to-[#d4af37] transform -translate-x-1/2 hidden md:block" />

          {memories.map((memory, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className={`relative mb-16 md:mb-24 ${
                index % 2 === 0 ? 'md:pr-1/2' : 'md:pl-1/2 md:ml-auto'
              }`}
            >
              <div className={`flex flex-col md:flex-row gap-6 items-center ${
                index % 2 === 0 ? 'md:flex-row-reverse md:text-right' : ''
              }`}>
                {/* Timeline dot */}
                <motion.div
                  whileHover={{ scale: 1.2 }}
                  className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-[#d4af37] border-4 border-black z-10"
                  style={{
                    boxShadow: '0 0 20px rgba(212, 175, 55, 0.8)',
                  }}
                />

                {/* Content card */}
                <div className="w-full md:w-[calc(50%-3rem)]">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="glass-dark rounded-2xl overflow-hidden"
                  >
                    {/* Image */}
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={memory.image}
                        alt={memory.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                      
                      {/* Year badge */}
                      <div className="absolute top-4 left-4 glass-dark px-4 py-2 rounded-full flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-[#d4af37]" />
                        <span className="text-[#d4af37] font-bold">{memory.year}</span>
                      </div>
                    </div>

                    {/* Text content */}
                    <div className="p-6">
                      <h3 className="text-2xl font-bold text-[#d4af37] mb-3 flex items-center gap-2">
                        {index % 2 === 0 && <Heart className="w-5 h-5" />}
                        {memory.title}
                        {index % 2 !== 0 && <Heart className="w-5 h-5" />}
                      </h3>
                      <p className="text-white/80 leading-relaxed">
                        {memory.description}
                      </p>
                    </div>

                    {/* Glow effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/5 to-transparent rounded-2xl pointer-events-none" />
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* End marker */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="flex justify-center mt-12"
        >
          <div className="glass-dark px-8 py-4 rounded-full">
            <span className="text-[#d4af37] text-xl font-bold">
              The Journey Continues... 💫
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
