import { motion, AnimatePresence } from 'motion/react';
import { useState, useRef, useEffect } from 'react';
import { Music, Volume2, VolumeX } from 'lucide-react';

export function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Lo-fi music URL (using a free sample)
  const musicUrl = 'https://www.bensound.com/bensound-music/bensound-slowmotion.mp3';

  useEffect(() => {
    // Hide controls after 3 seconds
    const timer = setTimeout(() => {
      setShowControls(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(err => {
          console.log('Audio play failed:', err);
        });
      }
      setIsPlaying(!isPlaying);
    }
    setShowControls(true);
  };

  return (
    <>
      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        loop
        src={musicUrl}
        preload="none"
      />

      {/* Music toggle button */}
      <motion.div
        className="fixed bottom-8 right-8 z-40"
        onHoverStart={() => setShowControls(true)}
        onHoverEnd={() => setShowControls(false)}
      >
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleMusic}
          className="glass-dark p-4 rounded-full shadow-lg border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all"
          style={{
            boxShadow: isPlaying ? '0 0 30px rgba(212, 175, 55, 0.5)' : undefined,
          }}
        >
          {isPlaying ? (
            <Volume2 className="w-6 h-6 text-[#d4af37]" />
          ) : (
            <VolumeX className="w-6 h-6 text-white/60" />
          )}
        </motion.button>

        {/* Label */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="absolute right-full mr-4 top-1/2 -translate-y-1/2 glass-dark px-4 py-2 rounded-lg whitespace-nowrap"
            >
              <div className="flex items-center gap-2">
                <Music className="w-4 h-4 text-[#d4af37]" />
                <span className="text-white text-sm">
                  {isPlaying ? 'Music Playing' : 'Click to Play Music'}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Pulsing ring when playing */}
        {isPlaying && (
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-[#d4af37]"
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.5, 0, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          />
        )}
      </motion.div>
    </>
  );
}
