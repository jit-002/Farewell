import { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, X, Image as ImageIcon, Smartphone } from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';
import { toast } from 'sonner@2.0.3';
import { getDeviceFingerprint, getDeviceInfo } from '../utils/deviceFingerprint';

interface Photo {
  id: string;
  url: string;
  deviceId: string;
  deviceInfo: string;
  uploadedAt: number;
}

const MOCK_PHOTOS: Photo[] = [
  {
    id: '1',
    url: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800',
    deviceId: 'mock_device',
    deviceInfo: 'Mock Device',
    uploadedAt: Date.now(),
  },
  {
    id: '2',
    url: 'https://images.unsplash.com/photo-1627556704302-624c79e8b863?w=800',
    deviceId: 'mock_device',
    deviceInfo: 'Mock Device',
    uploadedAt: Date.now(),
  },
  {
    id: '3',
    url: 'https://images.unsplash.com/photo-1529390079861-591de354faf5?w=800',
    deviceId: 'mock_device',
    deviceInfo: 'Mock Device',
    uploadedAt: Date.now(),
  },
  {
    id: '4',
    url: 'https://images.unsplash.com/photo-1571260899304-425eee4c7efc?w=800',
    deviceId: 'mock_device',
    deviceInfo: 'Mock Device',
    uploadedAt: Date.now(),
  },
];

export function PhotoGallery() {
  const [photos, setPhotos] = useState<Photo[]>(MOCK_PHOTOS);
  const [activeTab, setActiveTab] = useState<'pre' | 'post'>('pre');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const currentDeviceId = getDeviceFingerprint();
  const currentDeviceInfo = getDeviceInfo();

  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: 'start',
    dragFree: true,
    containScroll: 'trimSnaps',
  });

  const [scrollProgress, setScrollProgress] = useState(0);

  const onScroll = useCallback(() => {
    if (!emblaApi) return;
    const progress = Math.max(0, Math.min(1, emblaApi.scrollProgress()));
    setScrollProgress(progress);
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onScroll();
    emblaApi.on('scroll', onScroll);
    return () => {
      emblaApi.off('scroll', onScroll);
    };
  }, [emblaApi, onScroll]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  };

  const handleFiles = (files: File[]) => {
    const imageFiles = files.filter((file) => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
      toast.error('Please upload image files only');
      return;
    }

    imageFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const newPhoto: Photo = {
          id: `${Date.now()}_${Math.random()}`,
          url: e.target?.result as string,
          deviceId: currentDeviceId,
          deviceInfo: currentDeviceInfo,
          uploadedAt: Date.now(),
        };
        setPhotos((prev) => [...prev, newPhoto]);
        toast.success('Photo uploaded successfully!');
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDelete = (photoId: string, photoDeviceId: string) => {
    if (photoDeviceId !== currentDeviceId && photoDeviceId !== 'mock_device') {
      toast.error('You can only delete photos uploaded from this device');
      return;
    }

    setPhotos((prev) => prev.filter((p) => p.id !== photoId));
    toast.success('Photo deleted successfully');
  };

  const canDelete = (photoDeviceId: string) => {
    return photoDeviceId === currentDeviceId || photoDeviceId === 'mock_device';
  };

  return (
    <section className="relative min-h-screen py-20 overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-[#ffd700] via-[#d4af37] to-[#ffd700] bg-clip-text text-transparent">
            Photo Gallery
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Captured moments that tell our story
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="flex justify-center gap-4 mb-8">
          {['pre', 'post'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as 'pre' | 'post')}
              className={`px-8 py-3 rounded-full font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-[#d4af37] text-black'
                  : 'glass-dark text-gray-300 hover:text-white'
              }`}
            >
              {tab === 'pre' ? 'Pre-Release' : 'Post-Release'}
            </button>
          ))}
        </div>

        {/* Upload Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto mb-12"
        >
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`glass-dark rounded-2xl border-2 border-dashed transition-all cursor-pointer ${
              isDragging
                ? 'border-[#d4af37] bg-[#d4af37]/10 scale-105'
                : 'border-[#d4af37]/30 hover:border-[#d4af37]/60'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="p-12 text-center">
              <Upload className="w-16 h-16 text-[#d4af37] mx-auto mb-4" />
              <h3 className="text-2xl font-semibold text-white mb-2">
                Upload Your Memories
              </h3>
              <p className="text-gray-400 mb-4">
                Drag and drop photos here, or click to select files
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                <Smartphone className="w-4 h-4" />
                <span>Device: {currentDeviceInfo}</span>
              </div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        </motion.div>

        {/* Carousel */}
        <div className="relative">
          {photos.length === 0 ? (
            <div className="glass-dark rounded-2xl p-20 text-center">
              <ImageIcon className="w-20 h-20 text-[#d4af37]/30 mx-auto mb-4" />
              <p className="text-xl text-gray-400">No photos yet. Upload your first memory!</p>
            </div>
          ) : (
            <>
              <div className="overflow-hidden" ref={emblaRef}>
                <div className="flex gap-6">
                  {photos.map((photo, index) => (
                    <motion.div
                      key={photo.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="relative flex-[0_0_80%] md:flex-[0_0_45%] lg:flex-[0_0_30%] group"
                    >
                      <div className="relative aspect-[4/5] rounded-2xl overflow-hidden glass-dark border-2 border-[#d4af37]/20">
                        <img
                          src={photo.url}
                          alt={`Memory ${index + 1}`}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        
                        {/* Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="absolute bottom-0 left-0 right-0 p-4">
                            <div className="flex items-center gap-2 text-sm text-gray-300 mb-2">
                              <Smartphone className="w-4 h-4" />
                              <span>{photo.deviceInfo}</span>
                            </div>
                            <p className="text-xs text-gray-400">
                              {new Date(photo.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>

                        {/* Delete Button */}
                        {canDelete(photo.deviceId) && (
                          <motion.button
                            initial={{ opacity: 0, scale: 0 }}
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            onClick={() => handleDelete(photo.id, photo.deviceId)}
                            className="absolute top-4 right-4 bg-red-500/90 hover:bg-red-600 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                          >
                            <X className="w-5 h-5" />
                          </motion.button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Scroll Progress Bar */}
              <div className="mt-8 max-w-xl mx-auto">
                <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#d4af37] to-[#ffd700]"
                    style={{ width: `${scrollProgress * 100}%` }}
                  />
                </div>
                <p className="text-center text-sm text-gray-400 mt-2">
                  Drag to explore • {photos.length} {photos.length === 1 ? 'photo' : 'photos'}
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
