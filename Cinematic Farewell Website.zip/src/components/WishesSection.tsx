import { motion } from 'motion/react';
import { useState } from 'react';
import { Heart, Send } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Wish {
  id: string;
  name: string;
  message: string;
  isPreset?: boolean;
}

export function WishesSection() {
  const [wishes, setWishes] = useState<Wish[]>([
    {
      id: '1',
      name: 'Class 11 Students',
      message: 'You were our inspiration, our mentors, and our friends. We will miss these corridors echoing with your laughter.',
      isPreset: true,
    },
    {
      id: '2',
      name: 'Your Juniors',
      message: "We'll miss seeing you around! You made this school feel like home. Best seniors ever! 💖",
      isPreset: true,
    },
    {
      id: '3',
      name: 'The Next Generation',
      message: 'Good luck legends! May you achieve everything you dream of. Thank you for setting the bar so high!',
      isPreset: true,
    },
    {
      id: '4',
      name: 'Forever Grateful',
      message: 'Thank you for all the memories, the guidance, and the unforgettable moments. You will always be remembered.',
      isPreset: true,
    },
  ]);

  const [formData, setFormData] = useState({
    name: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.message) {
      const newWish: Wish = {
        id: Date.now().toString(),
        name: formData.name,
        message: formData.message,
        isPreset: false,
      };
      setWishes([...wishes, newWish]);
      setFormData({ name: '', message: '' });
      toast.success('Your wish has been added! 💫');
    }
  };

  return (
    <section className="min-h-screen py-20 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#4a0e0e]/20 to-black" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2
            className="text-5xl md:text-7xl font-bold mb-4"
            style={{
              background: 'linear-gradient(to right, #ffd700, #d4af37, #ffd700)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Wishes & Messages
          </h2>
          <p className="text-xl text-white/70">
            Heartfelt messages from those who'll miss you
          </p>
        </motion.div>

        {/* Wishes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {wishes.map((wish, index) => (
            <motion.div
              key={wish.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="glass-dark rounded-2xl p-6 relative overflow-hidden group"
            >
              {/* Corner decoration */}
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-bl-full" />
              
              {/* Heart icon */}
              <Heart className="w-6 h-6 text-[#d4af37] mb-4 group-hover:fill-[#d4af37] transition-all" />
              
              {/* Message */}
              <p className="text-white/90 text-lg leading-relaxed mb-4 italic">
                "{wish.message}"
              </p>
              
              {/* Author */}
              <div className="flex items-center justify-between">
                <span className="text-[#d4af37] font-bold">— {wish.name}</span>
                {wish.isPreset && (
                  <span className="text-xs text-white/40 bg-white/5 px-2 py-1 rounded">
                    Preset
                  </span>
                )}
              </div>

              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
            </motion.div>
          ))}
        </div>

        {/* Add Wish Form */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <div className="glass-dark rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-[#d4af37] mb-6 text-center">
              Add Your Wish
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name input */}
              <div>
                <label className="block text-white/80 mb-2 text-sm">Your Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your name"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#d4af37] transition-all"
                  required
                />
              </div>

              {/* Message input */}
              <div>
                <label className="block text-white/80 mb-2 text-sm">Your Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Write your heartfelt message..."
                  rows={4}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#d4af37] transition-all resize-none"
                  required
                />
              </div>

              {/* Submit button */}
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-gradient-to-r from-[#d4af37] to-[#ffd700] text-black font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-all"
              >
                <Send className="w-5 h-5" />
                Send Your Wish
              </motion.button>
            </form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
