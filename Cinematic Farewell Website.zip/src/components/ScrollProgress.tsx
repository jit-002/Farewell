import { motion, useScroll, useSpring } from 'motion/react';
import { useEffect, useState } from 'react';

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const [lenisProgress, setLenisProgress] = useState(0);
  
  // Use Lenis scroll progress if available
  useEffect(() => {
    const updateProgress = () => {
      const lenis = (window as any).lenis;
      if (lenis) {
        const progress = lenis.progress || 0;
        setLenisProgress(progress);
      }
    };

    const interval = setInterval(updateProgress, 16); // ~60fps
    return () => clearInterval(interval);
  }, []);

  const scaleX = useSpring(lenisProgress > 0 ? lenisProgress : scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#d4af37] via-[#ffd700] to-[#d4af37] origin-left z-50"
      style={{
        scaleX,
        boxShadow: '0 0 20px rgba(212, 175, 55, 0.6)',
        transformOrigin: '0%',
      }}
    />
  );
}