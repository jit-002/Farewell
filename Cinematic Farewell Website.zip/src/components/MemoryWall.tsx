import { motion } from 'motion/react';
import { useState, useRef } from 'react';
import { Plus, X } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface StickyNote {
  id: string;
  text: string;
  color: string;
  position: { x: number; y: number };
}

const pastelColors = [
  '#FFD6E8', // Pink
  '#FFEAA7', // Yellow
  '#A8E6CF', // Green
  '#B4A7D6', // Purple
  '#FFB3BA', // Coral
  '#BAFFC9', // Mint
  '#BAE1FF', // Blue
  '#FFE5B4', // Peach
];

export function MemoryWall() {
  const [notes, setNotes] = useState<StickyNote[]>([
    {
      id: '1',
      text: 'Best moment? The last day tears! 😢',
      color: pastelColors[0],
      position: { x: 50, y: 50 },
    },
    {
      id: '2',
      text: 'Funniest memory: Science lab disasters! 🧪',
      color: pastelColors[1],
      position: { x: 200, y: 100 },
    },
    {
      id: '3',
      text: "What I'll miss: Canteen gossip sessions! ☕",
      color: pastelColors[2],
      position: { x: 400, y: 150 },
    },
    {
      id: '4',
      text: 'Thank you for being amazing! 💖',
      color: pastelColors[3],
      position: { x: 150, y: 300 },
    },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [newNoteText, setNewNoteText] = useState('');
  const boardRef = useRef<HTMLDivElement>(null);

  const handleAddNote = () => {
    if (newNoteText.trim()) {
      const newNote: StickyNote = {
        id: Date.now().toString(),
        text: newNoteText,
        color: pastelColors[Math.floor(Math.random() * pastelColors.length)],
        position: {
          x: Math.random() * 300 + 50,
          y: Math.random() * 200 + 50,
        },
      };
      setNotes([...notes, newNote]);
      setNewNoteText('');
      setShowForm(false);
      toast.success('Note added to the memory wall! 📌');
    }
  };

  const handleDeleteNote = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  const handleDragEnd = (id: string, event: any, info: any) => {
    if (!boardRef.current) return;

    const boardRect = boardRef.current.getBoundingClientRect();
    const noteWidth = 200;
    const noteHeight = 150;

    // Calculate new position with constraints
    let newX = info.point.x - boardRect.left;
    let newY = info.point.y - boardRect.top;

    // Constrain within bounds
    newX = Math.max(0, Math.min(newX, boardRect.width - noteWidth));
    newY = Math.max(0, Math.min(newY, boardRect.height - noteHeight));

    setNotes((prevNotes) =>
      prevNotes.map((note) =>
        note.id === id ? { ...note, position: { x: newX, y: newY } } : note
      )
    );
  };

  return (
    <section className="min-h-screen py-20 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#4a0e0e]/30 to-black" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2
            className="text-5xl md:text-7xl font-bold mb-4"
            style={{
              background: 'linear-gradient(to right, #ffd700, #d4af37, #ffd700)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Memory Wall
          </h2>
          <p className="text-xl text-white/70 mb-8">
            Pin your thoughts, memories, and feelings
          </p>

          {/* Add Note Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowForm(true)}
            className="glass-dark px-6 py-3 rounded-xl text-[#d4af37] font-bold flex items-center gap-2 mx-auto hover:border-[#d4af37] transition-all"
          >
            <Plus className="w-5 h-5" />
            Add Your Note
          </motion.button>
        </motion.div>

        {/* Memory Wall Board */}
        <motion.div
          ref={boardRef}
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative min-h-[600px] glass-dark rounded-3xl p-8"
          style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.05) 1px, transparent 0)',
            backgroundSize: '40px 40px',
            overflow: 'hidden',
          }}
        >
          {/* Cork board texture overlay */}
          <div className="absolute inset-0 opacity-5 pointer-events-none">
            <div className="w-full h-full" style={{
              backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 11px)',
            }} />
          </div>

          {/* Sticky Notes */}
          {notes.map((note, index) => (
            <motion.div
              key={note.id}
              drag
              dragMomentum={false}
              dragElastic={0}
              dragConstraints={boardRef}
              onDragEnd={(event, info) => handleDragEnd(note.id, event, info)}
              initial={{ opacity: 0, scale: 0, rotate: 0 }}
              animate={{
                opacity: 1,
                scale: 1,
                rotate: Math.random() * 10 - 5,
              }}
              whileHover={{ scale: 1.05, rotate: 0, zIndex: 10 }}
              whileDrag={{ scale: 1.1, rotate: 0, zIndex: 20 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="absolute cursor-move group"
              style={{
                left: note.position.x,
                top: note.position.y,
                width: '200px',
              }}
            >
              {/* Delete button */}
              <button
                onClick={() => handleDeleteNote(note.id)}
                className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
              >
                <X className="w-4 h-4 text-white" />
              </button>

              {/* Sticky note */}
              <div
                className="p-4 rounded-lg shadow-lg relative"
                style={{
                  backgroundColor: note.color,
                  boxShadow: '0 4px 6px rgba(0,0,0,0.2)',
                }}
              >
                {/* Pin */}
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-gray-700 shadow-md" />
                
                {/* Text */}
                <p className="text-gray-800 text-sm font-medium leading-relaxed break-words">
                  {note.text}
                </p>

                {/* Paper texture */}
                <div
                  className="absolute inset-0 opacity-10 pointer-events-none rounded-lg"
                  style={{
                    backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 3px)',
                  }}
                />
              </div>
            </motion.div>
          ))}

          {/* Helper text when empty */}
          {notes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-white/30 text-xl">
                Click "Add Your Note" to start pinning memories!
              </p>
            </div>
          )}
        </motion.div>
      </div>

      {/* Add Note Modal */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setShowForm(false)}
        >
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="glass-dark rounded-2xl p-8 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-bold text-[#d4af37] mb-6">
              Write Your Memory
            </h3>

            <textarea
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              placeholder="Share your favorite memory, funniest moment, or what you'll miss..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#d4af37] transition-all resize-none mb-6"
              rows={4}
              autoFocus
            />

            <div className="flex gap-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleAddNote}
                className="flex-1 bg-gradient-to-r from-[#d4af37] to-[#ffd700] text-black font-bold py-3 rounded-xl"
              >
                Add Note
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowForm(false)}
                className="flex-1 bg-white/10 text-white font-bold py-3 rounded-xl"
              >
                Cancel
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </section>
  );
}