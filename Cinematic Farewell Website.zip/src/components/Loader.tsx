import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export function Loader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 30);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black"
    >
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-[#4a0e0e] to-black opacity-80" />
      
      {/* Animated particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#d4af37] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Loader content */}
      <div className="relative z-10 flex flex-col items-center gap-8">
        {/* Circular spinner */}
        <div className="relative w-32 h-32">
          {/* Outer ring */}
          <motion.div
            className="absolute inset-0 rounded-full border-4 border-[#d4af37]/20"
            animate={{
              rotate: 360,
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: 'linear',
            }}
          >
            <div className="absolute top-0 left-1/2 w-2 h-2 -ml-1 -mt-1 bg-[#d4af37] rounded-full shadow-[0_0_20px_rgba(212,175,55,0.8)]" />
          </motion.div>

          {/* Middle ring */}
          <motion.div
            className="absolute inset-3 rounded-full border-4 border-[#ffd700]/30"
            animate={{
              rotate: -360,
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'linear',
            }}
          />

          {/* Inner glow */}
          <div className="absolute inset-6 rounded-full bg-gradient-to-br from-[#d4af37]/20 to-transparent blur-md" />
          
          {/* Center percentage */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold text-[#d4af37]">{progress}%</span>
          </div>
        </div>

        {/* Loading text */}
        <motion.div
          className="text-center"
          animate={{
            opacity: [1, 0.5, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        >
          <p className="text-2xl font-bold text-white mb-2" style={{ animation: 'glow 2s ease-in-out infinite' }}>
            Preparing Memories...
          </p>
          <p className="text-sm text-[#d4af37]/60">Loading your farewell experience</p>
        </motion.div>

        {/* Progress bar */}
        <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-[#d4af37] to-[#ffd700]"
            style={{
              width: `${progress}%`,
              boxShadow: '0 0 20px rgba(212, 175, 55, 0.6)',
            }}
            transition={{
              duration: 0.3,
            }}
          />
        </div>
      </div>
    </motion.div>
  );
}
