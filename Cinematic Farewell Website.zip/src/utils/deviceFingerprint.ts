// Generate a unique device fingerprint based on browser/device characteristics
export function getDeviceFingerprint(): string {
  // Check if fingerprint already exists in localStorage
  const existingFingerprint = localStorage.getItem('device_fingerprint');
  if (existingFingerprint) {
    return existingFingerprint;
  }

  // Generate fingerprint from various browser properties
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  let canvasFingerprint = '';
  
  if (ctx) {
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('Browser fingerprint', 2, 2);
    canvasFingerprint = canvas.toDataURL();
  }

  const fingerprint = {
    userAgent: navigator.userAgent,
    language: navigator.language,
    platform: navigator.platform,
    screenResolution: `${window.screen.width}x${window.screen.height}`,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    canvas: canvasFingerprint.slice(0, 100),
    timestamp: Date.now(),
  };

  // Create hash from fingerprint
  const fingerprintString = JSON.stringify(fingerprint);
  let hash = 0;
  for (let i = 0; i < fingerprintString.length; i++) {
    const char = fingerprintString.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }

  const deviceId = `device_${Math.abs(hash)}_${Date.now()}`;
  
  // Store in localStorage
  localStorage.setItem('device_fingerprint', deviceId);
  
  return deviceId;
}

export function getDeviceInfo(): string {
  const ua = navigator.userAgent;
  
  // Detect device type
  if (/mobile/i.test(ua)) {
    if (/android/i.test(ua)) return 'Android Phone';
    if (/iPad/i.test(ua)) return 'iPad';
    if (/iPhone/i.test(ua)) return 'iPhone';
    return 'Mobile Device';
  }
  
  if (/tablet/i.test(ua)) return 'Tablet';
  
  // Desktop browsers
  if (/chrome/i.test(ua) && !/edge/i.test(ua)) return 'Chrome Desktop';
  if (/safari/i.test(ua) && !/chrome/i.test(ua)) return 'Safari Desktop';
  if (/firefox/i.test(ua)) return 'Firefox Desktop';
  if (/edge/i.test(ua)) return 'Edge Desktop';
  
  return 'Desktop';
}
